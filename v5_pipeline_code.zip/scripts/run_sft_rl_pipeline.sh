#!/bin/bash
# =============================================================================
# SFT + RL (DPO) Two-Stage Pipeline Driver
#
# Implements the three key improvements from advisor feedback:
#   1. Multi-dimensional reward (composite reward as regularisation)
#   2. Multi-composition data diversity (multiple prompts)
#   3. SFT + RL two-stage pipeline
#
# Pipeline phases:
#   Phase 1: Multi-composition baseline generation + scoring
#   Phase 2: SFT on stable structures from all compositions
#   Phase 3: SFT model resample + composite reward scoring
#   Phase 4: Reward-weighted DPO on top of SFT model
#   Phase 5: Final evaluation + comparison report
#
# Usage:
#   source experiments/exp_sft_rl/config.sh
#   bash scripts/run_sft_rl_pipeline.sh
#
#   # Resume from last checkpoint:
#   RESUME=1 bash scripts/run_sft_rl_pipeline.sh
# =============================================================================
set -e

# Initialize conda
if [ -f "$HOME/miniconda3/etc/profile.d/conda.sh" ]; then
    source "$HOME/miniconda3/etc/profile.d/conda.sh"
elif [ -f "$HOME/anaconda3/etc/profile.d/conda.sh" ]; then
    source "$HOME/anaconda3/etc/profile.d/conda.sh"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"
DEBUG_LOG_DIR="${DEBUG_LOG_DIR:-$PROJECT_ROOT/.cursor}"
mkdir -p "$DEBUG_LOG_DIR" 2>/dev/null || true
export DEBUG_LOG_DIR

# ---- Required variables ----
: "${EXP_NAME:?'EXP_NAME must be set'}"
: "${TARGETS:?'TARGETS must be set (comma-separated, e.g. LiFePO4,NaCl,TiO2)'}"
: "${CRYSTALLM_CKPT_DIR:?'CRYSTALLM_CKPT_DIR must be set'}"
: "${CRYSTALLM_PKG_DIR:?'CRYSTALLM_PKG_DIR must be set'}"

# #region agent log
python3 - <<'PY'
import json
import os
import time

entry = {
    "sessionId": "25e703",
    "runId": "pre-fix-1",
    "hypothesisId": "H5",
    "location": "scripts/run_sft_rl_pipeline.sh:early_startup",
    "message": "pipeline script entered after required vars",
    "data": {
        "exp_name": os.environ.get("EXP_NAME", ""),
        "targets": os.environ.get("TARGETS", ""),
    },
    "timestamp": int(time.time() * 1000),
}
log_dir = os.environ.get("DEBUG_LOG_DIR", ".cursor")
with open(os.path.join(log_dir, "debug-25e703.log"), "a", encoding="utf-8") as f:
    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
PY
# #endregion

# ---- Defaults ----
NUM_SAMPLES=${NUM_SAMPLES:-10000}
TOP_K=${TOP_K:-10}
TEMPERATURE=${TEMPERATURE:-1.0}
SEED=${SEED:-42}
MAX_TOKENS=${MAX_TOKENS:-1024}
MAX_RETRIES=${MAX_RETRIES:-5}
GEN_BATCH_SIZE=${GEN_BATCH_SIZE:-16}
MATGL_FIX_LD_LIBRARY_PATH=${MATGL_FIX_LD_LIBRARY_PATH:-0}
export MATGL_FIX_LD_LIBRARY_PATH

# Quality gates
MIN_VALID_CIFS=${MIN_VALID_CIFS:-1000}
MIN_SCORED_CIFS=${MIN_SCORED_CIFS:-800}
MIN_PAIRS=${MIN_PAIRS:-500}

# Pair building
PAIR_STRATEGY=${PAIR_STRATEGY:-trimmed}
PAIR_GAP=${PAIR_GAP:-0.1}
PAIR_MIN_PER_PROMPT=${PAIR_MIN_PER_PROMPT:-1}
PAIR_MAX_PER_PROMPT=${PAIR_MAX_PER_PROMPT:-5000}
PAIR_TOP_PERCENT=${PAIR_TOP_PERCENT:-0.30}
PAIR_BOTTOM_PERCENT=${PAIR_BOTTOM_PERCENT:-0.30}
DPO_TOTAL_PAIRS=${DPO_TOTAL_PAIRS:-6000}

# Composite reward weights (Plan B)
REWARD_W_PROXY=${REWARD_W_PROXY:-0.45}
REWARD_W_GEOM=${REWARD_W_GEOM:-0.30}
REWARD_W_COMP=${REWARD_W_COMP:-0.20}
REWARD_W_NOVEL=${REWARD_W_NOVEL:-0.05}
REWARD_MIN_INTERATOMIC_DISTANCE=${REWARD_MIN_INTERATOMIC_DISTANCE:-0.6}
REWARD_ENABLE_DENSITY_GATE=${REWARD_ENABLE_DENSITY_GATE:-1}
REWARD_DENSITY_MIN=${REWARD_DENSITY_MIN:-0.1}
REWARD_DENSITY_MAX=${REWARD_DENSITY_MAX:-30.0}
REWARD_PROXY_BUFFER_SIZE=${REWARD_PROXY_BUFFER_SIZE:-50000}
REWARD_NOVELTY_WINDOW=${REWARD_NOVELTY_WINDOW:-2000}

# SFT (Stage 1)
SFT_STEPS=${SFT_STEPS:-6000}
SFT_LR=${SFT_LR:-5e-8}
SFT_GRAD_ACCUM=${SFT_GRAD_ACCUM:-8}
SFT_MAX_GRAD_NORM=${SFT_MAX_GRAD_NORM:-1.0}
SFT_SAVE_EVERY=${SFT_SAVE_EVERY:-1000}
SFT_WARMUP=${SFT_WARMUP:-200}
SFT_STRATEGY=${SFT_STRATEGY:-lora}
SFT_LORA_RANK=${SFT_LORA_RANK:-16}
SFT_WEIGHT_DECAY=${SFT_WEIGHT_DECAY:-0.01}
EHULL_THRESHOLD=${EHULL_THRESHOLD:-0.05}

# DPO (Stage 2)
DPO_STEPS=${DPO_STEPS:-4000}
DPO_BETA=${DPO_BETA:-2.5}
DPO_LR=${DPO_LR:-1e-7}
DPO_GRAD_ACCUM=${DPO_GRAD_ACCUM:-16}
DPO_MAX_GRAD_NORM=${DPO_MAX_GRAD_NORM:-1.0}
DPO_SAVE_EVERY=${DPO_SAVE_EVERY:-500}
DPO_WARMUP=${DPO_WARMUP:-200}
DPO_STRATEGY=${DPO_STRATEGY:-full}
DPO_LORA_RANK=${DPO_LORA_RANK:-16}
DPO_LOSS_TYPE=${DPO_LOSS_TYPE:-dpo}
DPO_LABEL_SMOOTHING=${DPO_LABEL_SMOOTHING:-0.1}
DPO_SIMPO_GAMMA=${DPO_SIMPO_GAMMA:-1.0}
DPO_REWARD_WEIGHTED=${DPO_REWARD_WEIGHTED:-1}
DPO_REWARD_ALPHA=${DPO_REWARD_ALPHA:-1.0}
DPO_WEIGHT_DECAY=${DPO_WEIGHT_DECAY:-0.01}

# Sampling diversity
TEMPERATURE_RANGE=${TEMPERATURE_RANGE:-}
TOP_K_RANGE=${TOP_K_RANGE:-}

# SFT ablation branches (empty = single default branch)
SFT_BRANCHES=${SFT_BRANCHES:-}

# Parse comma-separated targets
IFS=',' read -ra TARGET_LIST <<< "$TARGETS"

# Prompt Z map: e.g. "LiFePO4:4,NaCl:4,TiO2:4,BaTiO3:1"
declare -A PROMPT_Z_MAP_DICT
if [ -n "$PROMPT_Z_MAP" ]; then
    IFS=',' read -ra Z_ENTRIES <<< "$PROMPT_Z_MAP"
    for entry in "${Z_ENTRIES[@]}"; do
        IFS=':' read -ra KV <<< "$entry"
        if [ "${#KV[@]}" -ne 2 ] || [ -z "${KV[0]}" ] || [ -z "${KV[1]}" ]; then
            echo "ERROR: Invalid PROMPT_Z_MAP entry '$entry'. Expected format '<target>:<positive_int>' (e.g. LiFePO4:4)."
            exit 1
        fi
        if ! [[ "${KV[1]}" =~ ^[0-9]+$ ]] || [ "${KV[1]}" -le 0 ]; then
            echo "ERROR: Invalid Z value '${KV[1]}' in PROMPT_Z_MAP entry '$entry'. Must be a positive integer."
            exit 1
        fi
        PROMPT_Z_MAP_DICT["${KV[0]}"]="${KV[1]}"
    done
fi

# Experiment directories
EXP_DIR="outputs/$EXP_NAME"
REPORT_DIR="reports/$EXP_NAME"
mkdir -p "$EXP_DIR" "$REPORT_DIR"

# Log
LOG_FILE="$EXP_DIR/experiment.log"
exec > >(tee -a "$LOG_FILE") 2>&1

# #region agent log
debug_log() {
    local run_id="$1"
    local hypothesis_id="$2"
    local location="$3"
    local message="$4"
    local data_json="$5"
    python3 - "$run_id" "$hypothesis_id" "$location" "$message" "$data_json" <<'PY'
import json
import os
import sys
import time

run_id, hypothesis_id, location, message, data_json = sys.argv[1:]
try:
    data = json.loads(data_json) if data_json else {}
except Exception:
    data = {"raw": data_json}
entry = {
    "sessionId": "25e703",
    "runId": run_id,
    "hypothesisId": hypothesis_id,
    "location": location,
    "message": message,
    "data": data,
    "timestamp": int(time.time() * 1000),
}
log_dir = os.environ.get("DEBUG_LOG_DIR", ".cursor")
with open(os.path.join(log_dir, "debug-25e703.log"), "a", encoding="utf-8") as f:
    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
PY
}
# #endregion

# #region agent log
agent_log_ad14af() {
    local run_id="$1"
    local hypothesis_id="$2"
    local location="$3"
    local message="$4"
    local data_json="$5"
    python3 - "$run_id" "$hypothesis_id" "$location" "$message" "$data_json" <<'PY'
import json
import os
import sys
import time

run_id, hypothesis_id, location, message, data_json = sys.argv[1:]
try:
    data = json.loads(data_json) if data_json else {}
except Exception:
    data = {"raw": data_json}
entry = {
    "sessionId": "ad14af",
    "runId": run_id,
    "hypothesisId": hypothesis_id,
    "location": location,
    "message": message,
    "data": data,
    "timestamp": int(time.time() * 1000),
}
log_dir = os.environ.get("DEBUG_LOG_DIR", ".cursor")
with open(os.path.join(log_dir, "debug-ad14af.log"), "a", encoding="utf-8") as f:
    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
PY
}
# #endregion

echo "=========================================="
echo "SFT + RL Two-Stage Pipeline"
echo "Experiment: $EXP_NAME"
echo "Targets: ${TARGET_LIST[*]} (${#TARGET_LIST[@]} compositions)"
echo "Samples per target: $NUM_SAMPLES"
echo "SFT steps: $SFT_STEPS (LR=$SFT_LR, strategy=$SFT_STRATEGY)"
echo "DPO steps: $DPO_STEPS (LR=$DPO_LR, loss=$DPO_LOSS_TYPE)"
echo "Reward weights (Plan B): proxy=$REWARD_W_PROXY geom=$REWARD_W_GEOM comp=$REWARD_W_COMP novel=$REWARD_W_NOVEL"
echo "Started at: $(date)"
echo "=========================================="

# ---- Checkpoint / Resume support ----
CHECKPOINT_FILE="$EXP_DIR/.checkpoint"
RESUME=${RESUME:-0}

mark_step_done() { echo "$1" > "$CHECKPOINT_FILE"; echo "[checkpoint] Phase $1 done at $(date)"; }
last_done() { [ -f "$CHECKPOINT_FILE" ] && cat "$CHECKPOINT_FILE" || echo "0"; }

# Resume safety: phase markers can be stale if artifacts were cleaned or training failed.
has_sft_checkpoint_artifact() {
    local branch="$1"
    local sft_dir="$EXP_DIR/sft_$branch/checkpoint"
    if [ -f "$sft_dir/best_ckpt.pt" ] || [ -f "$sft_dir/ckpt.pt" ]; then
        return 0
    fi
    local step_ckpt
    step_ckpt=$(python3 -c "
from pathlib import Path
p = Path('$sft_dir')
cands = sorted(p.glob('step_*/ckpt.pt'))
print(str(cands[-1]) if cands else '')
" 2>/dev/null || true)
    [ -n "$step_ckpt" ] && [ -f "$step_ckpt" ]
}

all_sft_checkpoints_ready() {
    local missing=0
    local branch
    for branch in "${BRANCH_LIST[@]}"; do
        branch=$(echo "$branch" | xargs)
        if ! has_sft_checkpoint_artifact "$branch"; then
            missing=$((missing + 1))
            agent_log_ad14af "post-fix-1" "H6" "scripts/run_sft_rl_pipeline.sh:resume_sft_check" "Missing SFT checkpoint during resume validation" "{\"branch\":\"$branch\",\"checkpoint_dir\":\"$EXP_DIR/sft_$branch/checkpoint\"}"
        fi
    done
    [ "$missing" -eq 0 ]
}

has_baseline_artifact() {
    local target="$1"
    local scored_dir="$EXP_DIR/$target/baseline/scored"
    local cif_dir="$EXP_DIR/$target/baseline/raw_cifs"
    if [ ! -f "$scored_dir/ehull_estimates.csv" ]; then
        return 1
    fi
    if [ ! -f "$scored_dir/composite_reward.csv" ]; then
        return 1
    fi
    local cif_count
    cif_count=$(find "$cif_dir" -maxdepth 1 -name "*.cif" 2>/dev/null | wc -l)
    [ "$cif_count" -gt 0 ]
}

all_baselines_ready() {
    local missing=0
    local target
    for target in "${TARGET_LIST[@]}"; do
        target=$(echo "$target" | xargs)
        if ! has_baseline_artifact "$target"; then
            missing=$((missing + 1))
            agent_log_ad14af "post-fix-3" "H7" "scripts/run_sft_rl_pipeline.sh:resume_phase1_check" "Missing baseline artifact during resume validation" "{\"target\":\"$target\",\"baseline_dir\":\"$EXP_DIR/$target/baseline\"}"
        fi
    done
    [ "$missing" -eq 0 ]
}

should_run() {
    local step="$1"; local last; last=$(last_done)
    if [ "$RESUME" = "1" ] && [ "$last" -ge "$step" ] 2>/dev/null; then
        # Phase 1 must not be skipped if baseline artifacts are missing.
        if [ "$step" -eq 1 ] && ! all_baselines_ready; then
            echo "[resume] Phase 1 marker exists (last=$last) but baseline artifacts missing; rerunning phase 1."
            agent_log_ad14af "post-fix-3" "H7" "scripts/run_sft_rl_pipeline.sh:resume_override_phase1" "Override resume skip for phase 1 due to missing baseline artifacts" "{\"last_done\":$last,\"step\":$step}"
            return 0
        fi
        # Phase 2 must not be skipped if SFT artifacts are missing.
        if [ "$step" -eq 2 ] && ! all_sft_checkpoints_ready; then
            echo "[resume] Phase 2 marker exists (last=$last) but SFT checkpoints missing; rerunning phase 2."
            agent_log_ad14af "post-fix-1" "H6" "scripts/run_sft_rl_pipeline.sh:resume_override_phase2" "Override resume skip for phase 2 due to missing SFT artifacts" "{\"last_done\":$last,\"step\":$step}"
            return 0
        fi
        echo "[resume] Skipping phase $step (already done, last=$last)"; return 1
    fi
    return 0
}

# Helper: check reward spread after composite reward scoring
check_reward_spread() {
    local scored_dir="$1" label="$2"
    python3 -c "
import json, sys
label = '$label'
try:
    d = json.load(open('$scored_dir/composite_reward_summary.json'))
    std = d['r_total']['std']
    r_geom = d.get('r_geom', {}).get('mean', 0)
    gate_fail_rate = d.get('gate_failure_rate', 0)
    if std < 0.05:
        print(f'  WARNING [{label}]: R_total std={std:.4f} < 0.05 — reward has almost no spread!')
    else:
        print(f'  Reward OK [{label}]: R_total std={std:.4f} r_geom={r_geom:.3f} gate_fail={gate_fail_rate:.3f}')
except Exception as e:
    print(f'  WARNING [{label}]: Could not read reward summary: {e}')
" 2>&1 || true
}

# Helper: merge labels.csv + ehull_scores.csv -> eval.csv
merge_eval_csv() {
    local scored_dir="$1"
    conda run -n myenv python3 -c "
import csv, sys
from pathlib import Path
scored = Path('$scored_dir')
labels_path = scored / 'labels.csv'
scores_path = scored / 'ehull_scores.csv'
out_path = scored / 'eval.csv'
try:
    labels = {}
    with open(labels_path, 'r') as f:
        for row in csv.DictReader(f): labels[row['file']] = row
    scores = {}
    with open(scores_path, 'r') as f:
        for row in csv.DictReader(f):
            v = row.get('score_e_per_atom', '').strip()
            if v: scores[row['file']] = v
    with open(out_path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['file','valid','formula','target','hit_target','score_e_per_atom','error'])
        w.writeheader()
        for file, lbl in labels.items():
            row = lbl.copy(); row['score_e_per_atom'] = scores.get(file, ''); w.writerow(row)
    print(f'  eval.csv: {len(labels)} labels, {len(scores)} scores merged')
except Exception as e:
    print(f'ERROR: Failed to merge eval.csv in {scored}: {e}', file=sys.stderr)
    sys.exit(1)
" || echo "WARNING: eval.csv merge failed for $scored_dir"
}

# Helper: count non-empty MatGL score rows (excluding header/failed rows).
count_scored_rows() {
    local scores_csv="$1"
    python3 -c "
import csv
try:
    with open('$scores_csv', 'r', encoding='utf-8') as f:
        n = sum(1 for row in csv.DictReader(f) if (row.get('score_e_per_atom') or '').strip())
    print(n)
except Exception:
    print(0)
" 2>/dev/null || echo 0
}

# Helper: build CIF-format prompt for a target
build_prompt() {
    local target="$1"
    local z="${PROMPT_Z_MAP_DICT[$target]:-1}"
    # #region agent log
    debug_log "pre-fix-1" "H4" "run_sft_rl_pipeline.sh:BUILD_PROMPT" "Resolved prompt Z value for target" "{\"target\":\"$target\",\"z_raw\":\"$z\"}"
    # #endregion
    python3 -c "
import re
formula, z = '$target', int('$z')
pairs = re.findall(r'([A-Z][a-z]?)(\d*)', formula)
parts = []
for elem, cnt in pairs:
    if not elem: continue
    n = int(cnt) if cnt else 1
    n *= z
    parts.append(f'{elem}{n}' if n > 1 else elem)
print(f'data_{\"\" .join(parts)}')
"
}

# ---- Ablation branch support ----
# If SFT_BRANCHES is set, we run multiple SFT→DPO pipelines.
# Otherwise fall back to single-branch behaviour using top-level SFT_* vars.
if [ -n "$SFT_BRANCHES" ]; then
    IFS=',' read -ra BRANCH_LIST <<< "$SFT_BRANCHES"
else
    BRANCH_LIST=("default")
fi
agent_log_ad14af "precheck-1" "H3" "scripts/run_sft_rl_pipeline.sh:branch_parse" "Parsed SFT branches from config" "{\"sft_branches_raw\":\"$SFT_BRANCHES\",\"branch_count\":${#BRANCH_LIST[@]},\"targets\":\"$TARGETS\"}"

# Lookup branch-specific variable; fall back to top-level SFT_* default.
branch_var() {
    local branch="$1" var="$2" default="$3"
    local full="SFT_${branch}_${var}"
    if [ -n "${!full+x}" ]; then
        echo "${!full}"
    else
        echo "$default"
    fi
}

echo "SFT branches: ${BRANCH_LIST[*]} (${#BRANCH_LIST[@]})"

# =====================================================================
# PHASE 1: Multi-composition baseline generation + scoring
# =====================================================================
if should_run 1; then
echo ""
echo "=========================================="
echo "Phase 1: Multi-Composition Baseline Generation"
echo "=========================================="

for target in "${TARGET_LIST[@]}"; do
    target=$(echo "$target" | xargs)  # trim
    PROMPT_CIF=$(build_prompt "$target")
    TARGET_DIR="$EXP_DIR/$target/baseline"
    CIF_DIR="$TARGET_DIR/raw_cifs"
    SCORED_DIR="$TARGET_DIR/scored"
    VALID_DIR="$SCORED_DIR/valid_cifs"

    echo ""
    echo "---- Target: $target  Prompt: $PROMPT_CIF ----"
    mkdir -p "$CIF_DIR" "$SCORED_DIR" "$VALID_DIR"

    # Diversity args
    DIVERSITY_ARGS=""
    [ -n "$TEMPERATURE_RANGE" ] && DIVERSITY_ARGS="$DIVERSITY_ARGS --temperature_range $TEMPERATURE_RANGE"
    [ -n "$TOP_K_RANGE" ] && DIVERSITY_ARGS="$DIVERSITY_ARGS --top_k_range $TOP_K_RANGE"

    # Generate
    export MAX_RETRIES
    conda run -n myenv python "$SCRIPT_DIR/40_generate_cifs_crystallm.py" \
        --ckpt_dir "$CRYSTALLM_CKPT_DIR" \
        --pkg_dir "$CRYSTALLM_PKG_DIR" \
        --out_dir "$CIF_DIR" \
        --prompt "$PROMPT_CIF" \
        --n "$NUM_SAMPLES" \
        --max_tokens "$MAX_TOKENS" \
        --top_k "$TOP_K" \
        --temperature "$TEMPERATURE" \
        --seed "$SEED" \
        --batch_size "$GEN_BATCH_SIZE" \
        --device cuda \
        $DIVERSITY_ARGS

    # Validate
    conda run -n myenv python "$SCRIPT_DIR/11_validate_cifs.py" \
        --in_dir "$CIF_DIR" --out_dir "$SCORED_DIR"

    # Quality gate: valid CIF count
    N_VALID=$(find "$VALID_DIR" -maxdepth 1 -name "*.cif" 2>/dev/null | wc -l)
    echo "  Valid CIFs: $N_VALID (gate: $MIN_VALID_CIFS)"
    if [ "$N_VALID" -lt "$MIN_VALID_CIFS" ]; then
        echo "ERROR: Too few valid CIFs for $target ($N_VALID < $MIN_VALID_CIFS). Aborting."
        exit 1
    fi

    # Label
    conda run -n myenv python "$SCRIPT_DIR/12_label_cifs.py" \
        --in_dir "$CIF_DIR" --out_csv "$SCORED_DIR/labels.csv" --target "$target"

    # MatGL scoring
    conda run -n matgl_env bash -c "
        [ \"\$MATGL_FIX_LD_LIBRARY_PATH\" = '1' ] && export LD_LIBRARY_PATH=\"\$CONDA_PREFIX/lib:\$LD_LIBRARY_PATH\"
        python $SCRIPT_DIR/35_score_dir_matgl.py --in_dir $VALID_DIR --out_csv $SCORED_DIR/ehull_scores.csv
    "

    # Quality gate: scored CIF count (only rows with non-empty score_e_per_atom)
    N_SCORED=$(count_scored_rows "$SCORED_DIR/ehull_scores.csv")
    echo "  Scored CIFs: $N_SCORED (gate: $MIN_SCORED_CIFS)"
    if [ "$N_SCORED" -lt "$MIN_SCORED_CIFS" ]; then
        echo "ERROR: Too few scored CIFs for $target ($N_SCORED < $MIN_SCORED_CIFS). Aborting."
        exit 1
    fi

    merge_eval_csv "$SCORED_DIR"

    # Ehull estimation
    if ! conda run -n myenv python "$SCRIPT_DIR/36_estimate_ehull.py" \
        --scores_csv "$SCORED_DIR/ehull_scores.csv" \
        --out_csv "$SCORED_DIR/ehull_estimates.csv"; then
        echo "ERROR: Ehull failed for $target. Aborting."
        exit 1
    fi

    # Composite reward
    echo "Computing composite reward for $target ..."
    if ! conda run -n myenv python "$SCRIPT_DIR/48_compute_composite_reward.py" \
        --scores_csv "$SCORED_DIR/ehull_scores.csv" \
        --cif_dir "$CIF_DIR" \
        --target "$target" \
        --out_csv "$SCORED_DIR/composite_reward.csv" \
        --w_proxy "$REWARD_W_PROXY" \
        --w_geom "$REWARD_W_GEOM" \
        --w_comp "$REWARD_W_COMP" \
        --w_novel "$REWARD_W_NOVEL" \
        --min_interatomic_distance "$REWARD_MIN_INTERATOMIC_DISTANCE" \
        --proxy_buffer_size "$REWARD_PROXY_BUFFER_SIZE" \
        --novelty_window "$REWARD_NOVELTY_WINDOW" \
        --rolling_buffer_dir "$EXP_DIR/reward_buffers" \
        $( [ "$REWARD_ENABLE_DENSITY_GATE" = "1" ] && echo "--enable_density_gate" ) \
        --density_min "$REWARD_DENSITY_MIN" \
        --density_max "$REWARD_DENSITY_MAX"; then
        echo "ERROR: Composite reward failed for $target. Aborting."
        exit 1
    fi

    check_reward_spread "$SCORED_DIR" "baseline/$target"

    echo "---- $target baseline done ----"
done

mark_step_done 1
fi

# =====================================================================
# PHASE 2: SFT on stable structures — one per ablation branch
# =====================================================================

if should_run 2; then
echo ""
echo "=========================================="
echo "Phase 2: Multi-Composition SFT Training"
echo "=========================================="

# Prepare shared SFT training data (once)
SFT_DATA_DIR="$EXP_DIR/sft_shared"
mkdir -p "$SFT_DATA_DIR"

EHULL_CSVS=""
CIF_DIRS=""
for target in "${TARGET_LIST[@]}"; do
    target=$(echo "$target" | xargs)
    EHULL_CSVS="${EHULL_CSVS:+$EHULL_CSVS,}$EXP_DIR/$target/baseline/scored/ehull_estimates.csv"
    CIF_DIRS="${CIF_DIRS:+$CIF_DIRS,}$EXP_DIR/$target/baseline/raw_cifs"
done

SFT_JSONL="$SFT_DATA_DIR/sft_data.jsonl"
if [ ! -f "$SFT_JSONL" ] || [ ! -s "$SFT_JSONL" ]; then
    echo "Preparing multi-composition SFT data ..."
    conda run -n myenv python "$SCRIPT_DIR/47_prepare_sft_data.py" \
        --ehull_csv "$EHULL_CSVS" \
        --cif_dir "$CIF_DIRS" \
        --pkg_dir "$CRYSTALLM_PKG_DIR" \
        --out_jsonl "$SFT_JSONL" \
        --ehull_threshold "$EHULL_THRESHOLD" \
        --max_tokens "$MAX_TOKENS"
fi

SFT_DATA_COUNT=$(wc -l < "$SFT_JSONL" 2>/dev/null || echo 0)
echo "SFT training data: $SFT_DATA_COUNT samples"

if [ "$SFT_DATA_COUNT" -lt 10 ]; then
    echo "ERROR: Too few SFT samples ($SFT_DATA_COUNT). Aborting."
    exit 1
fi

# Train each branch
for branch in "${BRANCH_LIST[@]}"; do
    branch=$(echo "$branch" | xargs)
    B_STRATEGY=$(branch_var "$branch" STRATEGY "${SFT_STRATEGY:-lora}")
    B_LR=$(branch_var "$branch" LR "${SFT_LR:-5e-8}")
    B_STEPS=$(branch_var "$branch" STEPS "${SFT_STEPS:-6000}")
    B_GRAD_ACCUM=$(branch_var "$branch" GRAD_ACCUM "${SFT_GRAD_ACCUM:-8}")
    B_WARMUP=$(branch_var "$branch" WARMUP "${SFT_WARMUP:-200}")
    B_LORA_RANK=$(branch_var "$branch" LORA_RANK "${SFT_LORA_RANK:-16}")
    B_LORA_TARGETS=$(branch_var "$branch" LORA_TARGETS "c_attn")
    B_WEIGHT_DECAY=$(branch_var "$branch" WEIGHT_DECAY "${SFT_WEIGHT_DECAY:-0.01}")
    B_MAX_GRAD_NORM=$(branch_var "$branch" MAX_GRAD_NORM "${SFT_MAX_GRAD_NORM:-1.0}")
    B_SAVE_EVERY=$(branch_var "$branch" SAVE_EVERY "${SFT_SAVE_EVERY:-1000}")

    SFT_BRANCH_DIR="$EXP_DIR/sft_$branch"
    SFT_BRANCH_CKPT="$SFT_BRANCH_DIR/checkpoint"
    mkdir -p "$SFT_BRANCH_CKPT"

    echo ""
    echo "---- SFT branch: $branch (strategy=$B_STRATEGY, lr=$B_LR, steps=$B_STEPS, wd=$B_WEIGHT_DECAY) ----"

    LORA_ARGS=""
    if [ "$B_STRATEGY" = "lora" ]; then
        LORA_ARGS="--lora_rank $B_LORA_RANK"
        [ -n "$B_LORA_TARGETS" ] && LORA_ARGS="$LORA_ARGS --lora_target_names $B_LORA_TARGETS"
    fi

    conda run -n dpo_crystallm python "$SCRIPT_DIR/33_train_sft_crystallm.py" \
        --data_jsonl "$SFT_JSONL" \
        --ckpt_dir "$CRYSTALLM_CKPT_DIR" \
        --pkg_dir "$CRYSTALLM_PKG_DIR" \
        --out_dir "$SFT_BRANCH_CKPT" \
        --steps "$B_STEPS" \
        --lr "$B_LR" \
        --grad_accum_steps "$B_GRAD_ACCUM" \
        --max_grad_norm "$B_MAX_GRAD_NORM" \
        --save_every "$B_SAVE_EVERY" \
        --warmup_steps "$B_WARMUP" \
        --weight_decay "$B_WEIGHT_DECAY" \
        --strategy "$B_STRATEGY" \
        --device cuda \
        --seed "$SEED" \
        $LORA_ARGS

    echo "SFT [$branch] complete. Checkpoint: $SFT_BRANCH_CKPT/ckpt.pt"
done

mark_step_done 2
fi

# =====================================================================
# PHASE 3: SFT model resample + scoring + pair building (per branch)
# =====================================================================
if should_run 3; then
echo ""
echo "=========================================="
echo "Phase 3: SFT Model Resample + Scoring"
echo "=========================================="

PHASE3_SUCCESS_BRANCHES=0
for branch in "${BRANCH_LIST[@]}"; do
    branch=$(echo "$branch" | xargs)
    BRANCH_QUALIFIED_TARGETS=0
    SFT_BEST_CKPT="$EXP_DIR/sft_$branch/checkpoint/best_ckpt.pt"
    SFT_CKPT_FILE="$EXP_DIR/sft_$branch/checkpoint/ckpt.pt"
    if [ -f "$SFT_BEST_CKPT" ]; then
        SFT_CKPT_FILE="$SFT_BEST_CKPT"
        echo "Using best SFT checkpoint for branch=$branch: $SFT_CKPT_FILE"
    elif [ ! -f "$SFT_CKPT_FILE" ]; then
        echo "ERROR: SFT checkpoint not found for branch=$branch at $SFT_CKPT_FILE"
        exit 1
    fi

    echo ""
    echo "==== Branch: $branch ===="

    for target in "${TARGET_LIST[@]}"; do
        target=$(echo "$target" | xargs)
        PROMPT_CIF=$(build_prompt "$target")
        TARGET_DIR="$EXP_DIR/$target/sft_$branch"
        CIF_DIR="$TARGET_DIR/raw_cifs"
        SCORED_DIR="$TARGET_DIR/scored"
        VALID_DIR="$SCORED_DIR/valid_cifs"

        echo ""
        echo "---- SFT[$branch] resample: $target  Prompt: $PROMPT_CIF ----"
        mkdir -p "$CIF_DIR" "$SCORED_DIR" "$VALID_DIR"

        DIVERSITY_ARGS=""
        [ -n "$TEMPERATURE_RANGE" ] && DIVERSITY_ARGS="$DIVERSITY_ARGS --temperature_range $TEMPERATURE_RANGE"
        [ -n "$TOP_K_RANGE" ] && DIVERSITY_ARGS="$DIVERSITY_ARGS --top_k_range $TOP_K_RANGE"

        conda run -n myenv python "$SCRIPT_DIR/40_generate_cifs_crystallm.py" \
            --ckpt_dir "$SFT_CKPT_FILE" \
            --pkg_dir "$CRYSTALLM_PKG_DIR" \
            --out_dir "$CIF_DIR" \
            --prompt "$PROMPT_CIF" \
            --n "$NUM_SAMPLES" \
            --max_tokens "$MAX_TOKENS" \
            --top_k "$TOP_K" \
            --temperature "$TEMPERATURE" \
            --seed "$SEED" \
            --batch_size "$GEN_BATCH_SIZE" \
            --device cuda \
            $DIVERSITY_ARGS

        conda run -n myenv python "$SCRIPT_DIR/11_validate_cifs.py" \
            --in_dir "$CIF_DIR" --out_dir "$SCORED_DIR"

        # Validity gate
        TOTAL_GEN=$(find "$CIF_DIR" -maxdepth 1 -name "*.cif" 2>/dev/null | wc -l)
        TOTAL_VALID=$(find "$VALID_DIR" -maxdepth 1 -name "*.cif" 2>/dev/null | wc -l)
        if [ "$TOTAL_GEN" -gt 0 ]; then
            VALIDITY_CHECK=$(python3 -c "valid=$TOTAL_VALID; total=$TOTAL_GEN; pct=100*valid/total if total else 0.0; print(f'{pct:.1f} {1 if pct < 50 else 0}')")
            read -r VALID_PCT VALID_LT50 <<< "$VALIDITY_CHECK"
            echo "  Validity: $TOTAL_VALID / $TOTAL_GEN ($VALID_PCT%)"
            if [ "$VALID_LT50" = "1" ]; then
                echo "  WARNING: SFT[$branch] $target validity=$VALID_PCT% < 50% — model may be overfitting"
            fi
        fi
        if [ "$TOTAL_VALID" -lt "$MIN_VALID_CIFS" ]; then
            echo "ERROR: Too few valid CIFs for SFT[$branch] $target ($TOTAL_VALID < $MIN_VALID_CIFS). Aborting."
            exit 1
        fi

        conda run -n myenv python "$SCRIPT_DIR/12_label_cifs.py" \
            --in_dir "$CIF_DIR" --out_csv "$SCORED_DIR/labels.csv" --target "$target"
        conda run -n matgl_env bash -c "
            [ \"\$MATGL_FIX_LD_LIBRARY_PATH\" = '1' ] && export LD_LIBRARY_PATH=\"\$CONDA_PREFIX/lib:\$LD_LIBRARY_PATH\"
            python $SCRIPT_DIR/35_score_dir_matgl.py --in_dir $VALID_DIR --out_csv $SCORED_DIR/ehull_scores.csv
        "

        # Quality gate: scored CIF count (only rows with non-empty score_e_per_atom)
        N_SCORED=$(count_scored_rows "$SCORED_DIR/ehull_scores.csv")
        echo "  Scored CIFs: $N_SCORED (gate: $MIN_SCORED_CIFS)"
        if [ "$N_SCORED" -lt "$MIN_SCORED_CIFS" ]; then
            echo "ERROR: Too few scored CIFs for SFT[$branch] $target ($N_SCORED < $MIN_SCORED_CIFS). Aborting."
            exit 1
        fi

        merge_eval_csv "$SCORED_DIR"

        if ! conda run -n myenv python "$SCRIPT_DIR/36_estimate_ehull.py" \
            --scores_csv "$SCORED_DIR/ehull_scores.csv" \
            --out_csv "$SCORED_DIR/ehull_estimates.csv"; then
            echo "ERROR: Ehull failed for $target (SFT[$branch]). Aborting."
            exit 1
        fi

        if ! conda run -n myenv python "$SCRIPT_DIR/48_compute_composite_reward.py" \
            --scores_csv "$SCORED_DIR/ehull_scores.csv" \
            --cif_dir "$CIF_DIR" \
            --target "$target" \
            --out_csv "$SCORED_DIR/composite_reward.csv" \
            --w_proxy "$REWARD_W_PROXY" \
            --w_geom "$REWARD_W_GEOM" \
            --w_comp "$REWARD_W_COMP" \
            --w_novel "$REWARD_W_NOVEL" \
            --min_interatomic_distance "$REWARD_MIN_INTERATOMIC_DISTANCE" \
            --proxy_buffer_size "$REWARD_PROXY_BUFFER_SIZE" \
            --novelty_window "$REWARD_NOVELTY_WINDOW" \
            --rolling_buffer_dir "$EXP_DIR/reward_buffers" \
            $( [ "$REWARD_ENABLE_DENSITY_GATE" = "1" ] && echo "--enable_density_gate" ) \
            --density_min "$REWARD_DENSITY_MIN" \
            --density_max "$REWARD_DENSITY_MAX"; then
            echo "ERROR: Composite reward failed for $target (SFT[$branch]). Aborting."
            exit 1
        fi

        check_reward_spread "$SCORED_DIR" "SFT[$branch]/$target"

        PAIRS_DIR="$TARGET_DIR/pairs"
        mkdir -p "$PAIRS_DIR"
        if conda run -n myenv python "$SCRIPT_DIR/41_build_pairs_with_token_filter.py" \
            --labels_csv "$SCORED_DIR/labels.csv" \
            --scores_csv "$SCORED_DIR/ehull_scores.csv" \
            --reward_csv "$SCORED_DIR/composite_reward.csv" \
            --cif_dir "$CIF_DIR" \
            --pkg_dir "$CRYSTALLM_PKG_DIR" \
            --out_jsonl "$PAIRS_DIR/pairs.jsonl" \
            --target "$target" \
            --strategy "$PAIR_STRATEGY" \
            --max_tokens "$MAX_TOKENS" \
            --gap "$PAIR_GAP" \
            --seed "$SEED" \
            --top_percent "$PAIR_TOP_PERCENT" \
            --bottom_percent "$PAIR_BOTTOM_PERCENT" \
            --pair_min_per_prompt "$PAIR_MIN_PER_PROMPT" \
            --pair_max_per_prompt "$PAIR_MAX_PER_PROMPT" \
            --prompt_cif "$(build_prompt "$target")"; then
            N_PAIRS=$(wc -l < "$PAIRS_DIR/pairs.jsonl" 2>/dev/null || echo 0)
            echo "  Pairs: $N_PAIRS (gate: $MIN_PAIRS)"
            # #region agent log
            debug_log "pre-fix-1" "H2" "run_sft_rl_pipeline.sh:PHASE3_PAIRS" "Pair construction result per target" "{\"branch\":\"$branch\",\"target\":\"$target\",\"pairs\":$N_PAIRS,\"min_pairs\":$MIN_PAIRS,\"pair_max_per_prompt\":$PAIR_MAX_PER_PROMPT,\"pair_strategy\":\"$PAIR_STRATEGY\",\"pair_top_percent\":$PAIR_TOP_PERCENT,\"pair_bottom_percent\":$PAIR_BOTTOM_PERCENT}"
            # #endregion
            if [ "$N_PAIRS" -lt "$MIN_PAIRS" ]; then
                echo "WARNING: Too few pairs for $target [$branch] ($N_PAIRS < $MIN_PAIRS). Target excluded from DPO."
            else
                BRANCH_QUALIFIED_TARGETS=$((BRANCH_QUALIFIED_TARGETS + 1))
                echo "---- $target SFT[$branch] resample done ----"
            fi
        else
            echo "WARNING: Pair building failed for $target [$branch]. Skipping."
        fi
    done

    if [ "$BRANCH_QUALIFIED_TARGETS" -gt 0 ]; then
        PHASE3_SUCCESS_BRANCHES=$((PHASE3_SUCCESS_BRANCHES + 1))
        echo "Branch $branch qualified targets: $BRANCH_QUALIFIED_TARGETS"
    else
        echo "WARNING: Branch $branch produced no targets passing MIN_PAIRS=$MIN_PAIRS."
    fi
done

if [ "$PHASE3_SUCCESS_BRANCHES" -gt 0 ]; then
    mark_step_done 3
else
    echo "ERROR: Phase 3 failed — no branch produced targets passing MIN_PAIRS=$MIN_PAIRS."
    exit 1
fi
fi

# =====================================================================
# PHASE 4: DPO training — one per ablation branch
# =====================================================================

if should_run 4; then
echo ""
echo "=========================================="
echo "Phase 4: DPO Training"
echo "=========================================="

PHASE4_SUCCESS_BRANCHES=0
for branch in "${BRANCH_LIST[@]}"; do
    branch=$(echo "$branch" | xargs)
    DPO_DIR="$EXP_DIR/dpo_$branch"
    DPO_CKPT_DIR="$DPO_DIR/checkpoint"
    mkdir -p "$DPO_DIR" "$DPO_CKPT_DIR"

    echo ""
    echo "==== DPO for branch: $branch ===="

    PAIR_DIRS=""
    ACTIVE_TARGETS=()
    for target in "${TARGET_LIST[@]}"; do
        target=$(echo "$target" | xargs)
        PAIR_FILE="$EXP_DIR/$target/sft_$branch/pairs/pairs.jsonl"
        PAIR_COUNT=$(wc -l < "$PAIR_FILE" 2>/dev/null || echo 0)
        # #region agent log
        debug_log "pre-fix-1" "H1" "run_sft_rl_pipeline.sh:PHASE4_TARGET_FILTER" "Phase4 pair count before MIN_PAIRS filter" "{\"branch\":\"$branch\",\"target\":\"$target\",\"pair_count\":$PAIR_COUNT,\"min_pairs\":$MIN_PAIRS,\"dpo_total_pairs\":$DPO_TOTAL_PAIRS}"
        # #endregion
        if [ "$PAIR_COUNT" -ge "$MIN_PAIRS" ]; then
            PAIR_DIRS="${PAIR_DIRS:+$PAIR_DIRS,}$EXP_DIR/$target/sft_$branch"
            ACTIVE_TARGETS+=("$target")
            echo "  $target [$branch]: pairs=$PAIR_COUNT (>= $MIN_PAIRS)"
        elif [ -f "$PAIR_FILE" ] && [ -s "$PAIR_FILE" ]; then
            echo "WARNING: Skipping $target [$branch] (pairs=$PAIR_COUNT < MIN_PAIRS=$MIN_PAIRS)"
        else
            echo "WARNING: Skipping $target [$branch] (no pairs.jsonl or empty)"
        fi
    done

    if [ -z "$PAIR_DIRS" ]; then
        agent_log_ad14af "precheck-1" "H4" "scripts/run_sft_rl_pipeline.sh:phase4_no_active_targets" "No targets qualified for DPO in branch" "{\"branch\":\"$branch\",\"min_pairs\":$MIN_PAIRS,\"targets\":\"$TARGETS\"}"
        echo "ERROR: No targets produced valid pairs for branch=$branch. Skipping branch."
        continue
    fi
    TARGETS_CSV=$(IFS=','; echo "${ACTIVE_TARGETS[*]}")
    agent_log_ad14af "precheck-1" "H4" "scripts/run_sft_rl_pipeline.sh:phase4_active_targets" "Targets qualified for DPO in branch" "{\"branch\":\"$branch\",\"active_count\":${#ACTIVE_TARGETS[@]},\"active_targets\":\"$TARGETS_CSV\",\"min_pairs\":$MIN_PAIRS}"
    echo "Active targets for DPO[$branch]: ${ACTIVE_TARGETS[*]} (${#ACTIVE_TARGETS[@]}/${#TARGET_LIST[@]})"

    # Dynamic per-target allocation to exact DPO_TOTAL_PAIRS (no cross-target pairing).
    # #region agent log
    debug_log "pre-fix-1" "H1" "run_sft_rl_pipeline.sh:PHASE4_ACTIVE_TARGETS" "Active targets selected for DPO merge" "{\"branch\":\"$branch\",\"active_targets\":\"$TARGETS_CSV\",\"active_count\":${#ACTIVE_TARGETS[@]},\"total_targets\":${#TARGET_LIST[@]},\"dpo_total_pairs\":$DPO_TOTAL_PAIRS}"
    # #endregion
    if ! conda run -n myenv python3 -c "
import json, os, random, sys
from pathlib import Path
import time
exp_dir = Path('$EXP_DIR')
targets = [t for t in '$TARGETS_CSV'.split(',') if t]
branch = '$branch'
seed = int('$SEED')
requested_total = int('$DPO_TOTAL_PAIRS')
target_total = requested_total
out_path = Path('$DPO_DIR/merged_pairs.jsonl')
rng = random.Random(seed)
log_path = Path(os.environ.get('DEBUG_LOG_DIR', '.cursor')) / 'debug-25e703.log'
# #region agent log
def agent_log(hid, location, message, data):
    entry = {
        'sessionId': '25e703',
        'runId': 'pre-fix-1',
        'hypothesisId': hid,
        'location': location,
        'message': message,
        'data': data,
        'timestamp': int(time.time() * 1000),
    }
    with open(log_path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(entry, ensure_ascii=False) + '\\n')
# #endregion

per_target = {}
for t in targets:
    p = exp_dir / t / f'sft_{branch}' / 'pairs' / 'pairs.jsonl'
    rows = []
    if p.exists():
        with open(p, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
    if rows:
        per_target[t] = rows

if not per_target:
    # #region agent log
    agent_log('H1', 'run_sft_rl_pipeline.sh:PHASE4_MERGE', 'No per-target pairs available for merge', {'branch': branch, 'targets': targets})
    # #endregion
    print('ERROR: no available pair files', file=sys.stderr)
    sys.exit(1)

counts = {t: len(v) for t, v in per_target.items()}
total_available = sum(counts.values())
# #region agent log
agent_log('H1', 'run_sft_rl_pipeline.sh:PHASE4_MERGE', 'Pre-merge availability snapshot', {'branch': branch, 'counts': counts, 'total_available': total_available, 'requested_total': requested_total})
# #endregion
print(f'Available pairs by target: {counts} (total={total_available})')
if total_available < target_total:
    # #region agent log
    agent_log('H1', 'run_sft_rl_pipeline.sh:PHASE4_MERGE', 'Requested total exceeds available pairs; clipping to available', {'branch': branch, 'counts': counts, 'total_available': total_available, 'requested_total': requested_total, 'effective_target_total': total_available})
    # #endregion
    print(f'WARNING: available pairs {total_available} < requested {target_total}; clipping target_total to {total_available}')
    target_total = total_available
if target_total <= 0:
    print('ERROR: effective target_total is 0 after clipping', file=sys.stderr)
    sys.exit(2)

# Dynamic split proportional to availability.
raw = {t: target_total * counts[t] / total_available for t in per_target}
alloc = {t: int(raw[t]) for t in per_target}
remainder = target_total - sum(alloc.values())
order = sorted(per_target.keys(), key=lambda t: (raw[t] - alloc[t]), reverse=True)
for i in range(remainder):
    alloc[order[i % len(order)]] += 1

# Capacity correction.
deficit = 0
for t in list(alloc.keys()):
    if alloc[t] > counts[t]:
        deficit += alloc[t] - counts[t]
        alloc[t] = counts[t]
if deficit > 0:
    grow = [t for t in alloc if alloc[t] < counts[t]]
    idx = 0
    while deficit > 0 and grow:
        t = grow[idx % len(grow)]
        if alloc[t] < counts[t]:
            alloc[t] += 1
            deficit -= 1
        idx += 1
if sum(alloc.values()) != target_total:
    # #region agent log
    agent_log('H3', 'run_sft_rl_pipeline.sh:PHASE4_MERGE', 'Allocation sum mismatch after correction', {'branch': branch, 'alloc': alloc, 'sum_alloc': sum(alloc.values()), 'target_total': target_total, 'counts': counts})
    # #endregion
    print('ERROR: failed to allocate exactly requested pairs', file=sys.stderr)
    sys.exit(3)
# #region agent log
agent_log('H3', 'run_sft_rl_pipeline.sh:PHASE4_MERGE', 'Allocation computed successfully', {'branch': branch, 'alloc': alloc, 'target_total': target_total, 'counts': counts})
# #endregion

merged = []
for t, n in alloc.items():
    rows = per_target[t]
    rng.shuffle(rows)
    chosen = rows[:n]
    for rec in chosen:
        rec['source_target'] = t
    merged.extend(chosen)
rng.shuffle(merged)

out_path.parent.mkdir(parents=True, exist_ok=True)
with open(out_path, 'w', encoding='utf-8') as f:
    for rec in merged:
        f.write(json.dumps(rec, ensure_ascii=False) + '\\n')

summary = {
    'requested_total_pairs': requested_total,
    'effective_target_pairs': target_total,
    'available_pairs_by_target': counts,
    'allocated_pairs_by_target': alloc,
    'merged_pairs': len(merged),
}
with open(out_path.parent / 'merge_pairs_summary.json', 'w', encoding='utf-8') as f:
    json.dump(summary, f, indent=2, ensure_ascii=False)
print(f'Allocated pairs by target: {alloc}')
print(f'Wrote merged pairs: {len(merged)} -> {out_path}')
"
    then
        echo "ERROR: Pair merge failed for branch=$branch. Skipping branch."
        continue
    fi

    MERGED_PAIRS=$(wc -l < "$DPO_DIR/merged_pairs.jsonl" 2>/dev/null || echo 0)
    EFFECTIVE_DPO_TOTAL_PAIRS=$(python3 -c "
import json
try:
    with open('$DPO_DIR/merge_pairs_summary.json', 'r', encoding='utf-8') as f:
        d = json.load(f)
    print(int(d.get('effective_target_pairs', d.get('requested_total_pairs', $DPO_TOTAL_PAIRS))))
except Exception:
    print(int('$DPO_TOTAL_PAIRS'))
" 2>/dev/null || echo "$DPO_TOTAL_PAIRS")
    echo "Total merged pairs [$branch]: $MERGED_PAIRS"

    if [ "$MERGED_PAIRS" -lt "$EFFECTIVE_DPO_TOTAL_PAIRS" ]; then
        echo "ERROR: Insufficient merged pairs for $branch ($MERGED_PAIRS < $EFFECTIVE_DPO_TOTAL_PAIRS). Skipping."
        continue
    fi

    SFT_BEST_CKPT="$EXP_DIR/sft_$branch/checkpoint/best_ckpt.pt"
    SFT_CKPT_FILE="$EXP_DIR/sft_$branch/checkpoint/ckpt.pt"
    if [ -f "$SFT_BEST_CKPT" ]; then
        SFT_CKPT_FILE="$SFT_BEST_CKPT"
        echo "Using best SFT checkpoint for DPO[$branch]: $SFT_CKPT_FILE"
    fi
    if [ ! -f "$SFT_CKPT_FILE" ]; then
        SFT_FALLBACK_STEP_CKPT=$(python3 -c "
from pathlib import Path
p = Path('$EXP_DIR/sft_$branch/checkpoint')
cands = sorted(p.glob('step_*/ckpt.pt'))
print(str(cands[-1]) if cands else '')
" 2>/dev/null || true)
        if [ -n "$SFT_FALLBACK_STEP_CKPT" ] && [ -f "$SFT_FALLBACK_STEP_CKPT" ]; then
            SFT_CKPT_FILE="$SFT_FALLBACK_STEP_CKPT"
            echo "Using fallback step checkpoint for DPO[$branch]: $SFT_CKPT_FILE"
        fi
    fi
    # #region agent log
    if [ -f "$SFT_CKPT_FILE" ]; then
        debug_log "post-fix-2" "H6" "run_sft_rl_pipeline.sh:PHASE4_SFT_CKPT" "Resolved SFT checkpoint for DPO branch" "{\"branch\":\"$branch\",\"sft_ckpt\":\"$SFT_CKPT_FILE\",\"exists\":true}"
    else
        debug_log "post-fix-2" "H6" "run_sft_rl_pipeline.sh:PHASE4_SFT_CKPT" "Missing SFT checkpoint for DPO branch" "{\"branch\":\"$branch\",\"sft_ckpt\":\"$SFT_CKPT_FILE\",\"exists\":false}"
        echo "ERROR: SFT checkpoint not found for DPO[$branch] at $SFT_CKPT_FILE. Skipping branch."
        continue
    fi
    # #endregion
    REWARD_ARGS=""
    if [ "$DPO_REWARD_WEIGHTED" = "1" ]; then
        REWARD_ARGS="--reward_weighted --reward_alpha $DPO_REWARD_ALPHA"
    fi

    echo "Training DPO[$branch] on SFT checkpoint ..."
    conda run -n dpo_crystallm python "$SCRIPT_DIR/32_train_dpo_crystallm.py" \
        --pairs "$DPO_DIR/merged_pairs.jsonl" \
        --ckpt_dir "$SFT_CKPT_FILE" \
        --pkg_dir "$CRYSTALLM_PKG_DIR" \
        --out_dir "$DPO_CKPT_DIR" \
        --steps "$DPO_STEPS" \
        --beta "$DPO_BETA" \
        --lr "$DPO_LR" \
        --grad_accum_steps "$DPO_GRAD_ACCUM" \
        --max_grad_norm "$DPO_MAX_GRAD_NORM" \
        --save_every "$DPO_SAVE_EVERY" \
        --strategy "$DPO_STRATEGY" \
        --lora_rank "$DPO_LORA_RANK" \
        --warmup_steps "$DPO_WARMUP" \
        --loss_type "$DPO_LOSS_TYPE" \
        --label_smoothing "$DPO_LABEL_SMOOTHING" \
        --simpo_gamma "$DPO_SIMPO_GAMMA" \
        --weight_decay "$DPO_WEIGHT_DECAY" \
        --device cuda \
        --seed "$SEED" \
        $REWARD_ARGS

    echo "DPO[$branch] training complete. Checkpoint: $DPO_CKPT_DIR/ckpt.pt"
    if [ -f "$DPO_CKPT_DIR/ckpt.pt" ] || [ -f "$DPO_CKPT_DIR/best_ckpt.pt" ]; then
        PHASE4_SUCCESS_BRANCHES=$((PHASE4_SUCCESS_BRANCHES + 1))
    else
        echo "WARNING: DPO[$branch] finished without checkpoint artifact."
    fi
done

if [ "$PHASE4_SUCCESS_BRANCHES" -gt 0 ]; then
    mark_step_done 4
else
    agent_log_ad14af "precheck-1" "H4" "scripts/run_sft_rl_pipeline.sh:phase4_failed" "Phase4 ended with zero successful branches" "{\"phase4_success_branches\":$PHASE4_SUCCESS_BRANCHES,\"branch_total\":${#BRANCH_LIST[@]}}"
    echo "ERROR: Phase 4 failed — no branch completed DPO training."
    exit 1
fi
fi

# =====================================================================
# PHASE 5: Final Evaluation + Cross-Branch Comparison
# =====================================================================
if should_run 5; then
echo ""
echo "=========================================="
echo "Phase 5: Final Evaluation + Comparison"
echo "=========================================="

PHASE5_SUCCESS_BRANCHES=0
for branch in "${BRANCH_LIST[@]}"; do
    branch=$(echo "$branch" | xargs)
    BRANCH_EVAL_OK=0
    DPO_BEST_CKPT="$EXP_DIR/dpo_$branch/checkpoint/best_ckpt.pt"
    DPO_FINAL_CKPT="$EXP_DIR/dpo_$branch/checkpoint/ckpt.pt"
    if [ -f "$DPO_BEST_CKPT" ]; then
        DPO_FINAL_CKPT="$DPO_BEST_CKPT"
        echo "Using best checkpoint for branch=$branch: $DPO_FINAL_CKPT"
    elif [ ! -f "$DPO_FINAL_CKPT" ]; then
        echo "WARNING: DPO checkpoint not found for branch=$branch. Skipping eval."
        continue
    fi

    EVAL_TARGETS=()
    for target in "${TARGET_LIST[@]}"; do
        target=$(echo "$target" | xargs)
        PAIR_FILE="$EXP_DIR/$target/sft_$branch/pairs/pairs.jsonl"
        PAIR_COUNT=$(wc -l < "$PAIR_FILE" 2>/dev/null || echo 0)
        if [ "$PAIR_COUNT" -ge "$MIN_PAIRS" ]; then
            EVAL_TARGETS+=("$target")
            echo "  $target eval [$branch]: pairs=$PAIR_COUNT (>= $MIN_PAIRS)"
        elif [ -f "$PAIR_FILE" ] && [ -s "$PAIR_FILE" ]; then
            echo "WARNING: Skipping $target evaluation [$branch] (pairs=$PAIR_COUNT < MIN_PAIRS=$MIN_PAIRS)"
        else
            echo "WARNING: Skipping $target evaluation [$branch] (no pairs)"
        fi
    done
    if [ "${#EVAL_TARGETS[@]}" -eq 0 ]; then
        echo "WARNING: No valid evaluation targets for branch=$branch. Skipping eval."
        continue
    fi
    echo "Evaluating branch=$branch targets: ${EVAL_TARGETS[*]}"

    for target in "${EVAL_TARGETS[@]}"; do
        target=$(echo "$target" | xargs)
        PROMPT_CIF=$(build_prompt "$target")

        echo ""
        echo "---- Final eval [$branch]: $target ----"

        FINAL_DIR="$EXP_DIR/$target/dpo_$branch"
        CIF_DIR="$FINAL_DIR/raw_cifs"
        SCORED_DIR="$FINAL_DIR/scored"
        VALID_DIR="$SCORED_DIR/valid_cifs"
        mkdir -p "$CIF_DIR" "$SCORED_DIR" "$VALID_DIR"

        DIVERSITY_ARGS=""
        [ -n "$TEMPERATURE_RANGE" ] && DIVERSITY_ARGS="$DIVERSITY_ARGS --temperature_range $TEMPERATURE_RANGE"
        [ -n "$TOP_K_RANGE" ] && DIVERSITY_ARGS="$DIVERSITY_ARGS --top_k_range $TOP_K_RANGE"

        conda run -n myenv python "$SCRIPT_DIR/40_generate_cifs_crystallm.py" \
            --ckpt_dir "$DPO_FINAL_CKPT" \
            --pkg_dir "$CRYSTALLM_PKG_DIR" \
            --out_dir "$CIF_DIR" \
            --prompt "$PROMPT_CIF" \
            --n "$NUM_SAMPLES" \
            --max_tokens "$MAX_TOKENS" \
            --top_k "$TOP_K" \
            --temperature "$TEMPERATURE" \
            --seed "$SEED" \
            --batch_size "$GEN_BATCH_SIZE" \
            --device cuda \
            $DIVERSITY_ARGS

        conda run -n myenv python "$SCRIPT_DIR/11_validate_cifs.py" \
            --in_dir "$CIF_DIR" --out_dir "$SCORED_DIR"
        conda run -n myenv python "$SCRIPT_DIR/12_label_cifs.py" \
            --in_dir "$CIF_DIR" --out_csv "$SCORED_DIR/labels.csv" --target "$target"
        conda run -n matgl_env bash -c "
            [ \"\$MATGL_FIX_LD_LIBRARY_PATH\" = '1' ] && export LD_LIBRARY_PATH=\"\$CONDA_PREFIX/lib:\$LD_LIBRARY_PATH\"
            python $SCRIPT_DIR/35_score_dir_matgl.py --in_dir $VALID_DIR --out_csv $SCORED_DIR/ehull_scores.csv
        "

        merge_eval_csv "$SCORED_DIR"

        conda run -n myenv python "$SCRIPT_DIR/36_estimate_ehull.py" \
            --scores_csv "$SCORED_DIR/ehull_scores.csv" \
            --out_csv "$SCORED_DIR/ehull_estimates.csv" \
            || echo "WARNING: Ehull failed for $target (DPO[$branch])"

        conda run -n myenv python "$SCRIPT_DIR/48_compute_composite_reward.py" \
            --scores_csv "$SCORED_DIR/ehull_scores.csv" \
            --cif_dir "$CIF_DIR" \
            --target "$target" \
            --out_csv "$SCORED_DIR/composite_reward.csv" \
            --w_proxy "$REWARD_W_PROXY" \
            --w_geom "$REWARD_W_GEOM" \
            --w_comp "$REWARD_W_COMP" \
            --w_novel "$REWARD_W_NOVEL" \
            --min_interatomic_distance "$REWARD_MIN_INTERATOMIC_DISTANCE" \
            --proxy_buffer_size "$REWARD_PROXY_BUFFER_SIZE" \
            --novelty_window "$REWARD_NOVELTY_WINDOW" \
            --rolling_buffer_dir "$EXP_DIR/reward_buffers" \
            $( [ "$REWARD_ENABLE_DENSITY_GATE" = "1" ] && echo "--enable_density_gate" ) \
            --density_min "$REWARD_DENSITY_MIN" \
            --density_max "$REWARD_DENSITY_MAX" \
            || echo "WARNING: Composite reward failed for $target (DPO[$branch])"

        check_reward_spread "$SCORED_DIR" "DPO[$branch]/$target"

        echo "---- $target [$branch] evaluation done ----"
    done

    # Three-way evaluation per branch: Baseline vs SFT vs SFT+DPO
    echo "Running three-way evaluation for branch=$branch ..."
    BASE_SCORED_LIST=""
    SFT_SCORED_LIST=""
    DPO_SCORED_LIST=""
    TARGET_LIST_STR=""
    for target in "${EVAL_TARGETS[@]}"; do
        target=$(echo "$target" | xargs)
        BASE_SCORED_LIST="${BASE_SCORED_LIST:+$BASE_SCORED_LIST,}$EXP_DIR/$target/baseline/scored"
        SFT_SCORED_LIST="${SFT_SCORED_LIST:+$SFT_SCORED_LIST,}$EXP_DIR/$target/sft_$branch/scored"
        DPO_SCORED_LIST="${DPO_SCORED_LIST:+$DPO_SCORED_LIST,}$EXP_DIR/$target/dpo_$branch/scored"
        TARGET_LIST_STR="${TARGET_LIST_STR:+$TARGET_LIST_STR,}$target"
    done

    if conda run -n myenv python "$SCRIPT_DIR/50_evaluate_three_way.py" \
        --baseline_dir "$BASE_SCORED_LIST" \
        --sft_dir "$SFT_SCORED_LIST" \
        --dpo_dir "$DPO_SCORED_LIST" \
        --target "$TARGET_LIST_STR" \
        --out_dir "$REPORT_DIR/three_way_$branch"; then
        BRANCH_EVAL_OK=1
    else
        echo "WARNING: Three-way evaluation failed for branch=$branch"
    fi
    if [ "$BRANCH_EVAL_OK" -eq 1 ]; then
        PHASE5_SUCCESS_BRANCHES=$((PHASE5_SUCCESS_BRANCHES + 1))
    fi
done

# Cross-branch summary
echo "Generating cross-branch summary ..."
SUMMARY_FILE="$REPORT_DIR/sft_rl_summary.md"
cat > "$SUMMARY_FILE" <<HEADER
# SFT + RL (DPO) Pipeline — $EXP_NAME Ablation Results

## Experiment Configuration

HEADER

cat >> "$SUMMARY_FILE" <<EOFCFG
- **Experiment**: $EXP_NAME
- **Targets**: ${TARGET_LIST[*]}
- **Samples per target**: $NUM_SAMPLES
- **SFT Branches**: ${BRANCH_LIST[*]}
- **DPO**: steps=$DPO_STEPS, lr=$DPO_LR, loss=$DPO_LOSS_TYPE, beta=$DPO_BETA
- **Reward weights (Plan B)**: proxy=$REWARD_W_PROXY, geom=$REWARD_W_GEOM, comp=$REWARD_W_COMP, novel=$REWARD_W_NOVEL
- **Reward-weighted DPO**: $DPO_REWARD_WEIGHTED (alpha=$DPO_REWARD_ALPHA)

## Per-Branch Per-Target Results

| Target | Branch | Baseline Stability | SFT Stability | DPO Stability |
|--------|--------|-------------------|---------------|---------------|
EOFCFG

for branch in "${BRANCH_LIST[@]}"; do
    branch=$(echo "$branch" | xargs)
    for target in "${TARGET_LIST[@]}"; do
        target=$(echo "$target" | xargs)
        BASE_RATE=$(python3 -c "
import json
try:
    with open('$EXP_DIR/$target/baseline/scored/ehull_summary.json') as f:
        d = json.load(f); print(f'{d[\"stability_rate\"]:.4f}')
except: print('N/A')
" 2>/dev/null)
        SFT_RATE=$(python3 -c "
import json
try:
    with open('$EXP_DIR/$target/sft_$branch/scored/ehull_summary.json') as f:
        d = json.load(f); print(f'{d[\"stability_rate\"]:.4f}')
except: print('N/A')
" 2>/dev/null)
        DPO_RATE=$(python3 -c "
import json
try:
    with open('$EXP_DIR/$target/dpo_$branch/scored/ehull_summary.json') as f:
        d = json.load(f); print(f'{d[\"stability_rate\"]:.4f}')
except: print('N/A')
" 2>/dev/null)
        echo "| $target | $branch | $BASE_RATE | $SFT_RATE | $DPO_RATE |" >> "$SUMMARY_FILE"
    done
done

echo "" >> "$SUMMARY_FILE"
echo "Generated at: $(date)" >> "$SUMMARY_FILE"
echo "Summary report: $SUMMARY_FILE"

if [ "$PHASE5_SUCCESS_BRANCHES" -gt 0 ]; then
    mark_step_done 5
else
    echo "ERROR: Phase 5 failed — no branch completed three-way evaluation."
    exit 1
fi
fi

# =====================================================================
# PHASE 6: Crystal Structure Visualisation (VESTA / ASE)
# =====================================================================
if should_run 6; then
echo ""
echo "=========================================="
echo "Phase 6: Structure Visualisation"
echo "=========================================="

BRANCH_STR=$(IFS=','; echo "${BRANCH_LIST[*]}")
TARGET_STR=$(IFS=','; echo "${TARGET_LIST[*]}")

VIZ_BACKEND="ase"
VESTA_BIN="${HOME}/tools/VESTA/VESTA"
if [ -x "$VESTA_BIN" ]; then
    VIZ_BACKEND="vesta"
fi

conda run -n myenv python "$SCRIPT_DIR/51_visualize_structures.py" \
    --exp_dir "$EXP_DIR" \
    --targets "$TARGET_STR" \
    --branches "$BRANCH_STR" \
    --top_n 10 \
    --out_dir "$REPORT_DIR/visualizations" \
    --backend "$VIZ_BACKEND" \
    --vesta_bin "$VESTA_BIN" \
    || echo "WARNING: Visualisation failed (non-fatal)"

mark_step_done 6
fi

echo ""
echo "=========================================="
echo "SFT + RL Pipeline Complete!"
echo "Report directory: $REPORT_DIR"
echo "Finished at: $(date)"
echo "=========================================="
